const admin = require('firebase-admin');
const { fal } = require('@fal-ai/client');

// Initialize Firebase
const saBase64 = process.env.FIREBASE_SERVICE_ACCOUNT_KEY || process.env.FB_SERVICE_ACCOUNT_KEY;
if (!saBase64) {
    throw new Error("Missing Firebase Service Account Key (FIREBASE_SERVICE_ACCOUNT_KEY or FB_SERVICE_ACCOUNT_KEY)");
}
const serviceAccount = JSON.parse(Buffer.from(saBase64, 'base64').toString('utf-8'));
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        storageBucket: process.env.FIREBASE_STORAGE_BUCKET || 'text2video-16cbf.firebasestorage.app'
    });
}

const db = admin.firestore();

// Configure Fal AI SDK
fal.config({
    credentials: process.env.FAL_API_VIDEO || process.env.FAL_API_KEY
});

exports.handler = async (event) => {
    // Note: 'event' here will contain the output from the 'Wait_For_Assets' state
    // Which includes the TTS URL and the original jobId/userId
    const { jobId, userId, avatarVideoUrl, taskToken, ttsUrl } = event;
    
    console.log(`🎬 Submitting LipSync job for Job: ${jobId}`);

    const webhookUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/api/fal/webhook`;

    // Submit LipSync job to Fal AI
    const submitResponse = await fal.queue.submit("veed/lipsync", {
        input: {
            video_url: avatarVideoUrl,
            audio_url: ttsUrl
        },
        webhookUrl: webhookUrl
    });

    const { request_id } = submitResponse;
    console.log(`✅ LipSync job submitted: ${request_id}`);

    // Store taskToken for the LipSync webhook
    await db.collection('falJobs').doc(request_id).set({
        userId,
        jobId,
        taskToken,
        type: 'lipsync'
    });

    // Update job status
    await db.collection('users').doc(userId).collection('aiInfluencerJobs').doc(jobId).update({
        status: 'submitting-lipsync',
        lipSyncRequestId: request_id
    });

    console.log(`✅ LipSync job submitted. Waiting for webhook to resume Step Function...`);
    // DO NOT RETURN - Let webhook resume the Step Function via SendTaskSuccess
};
