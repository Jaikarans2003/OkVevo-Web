const admin = require('firebase-admin');
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// ────────────────────────────────────────────────────
// Configuration
// ────────────────────────────────────────────────────
const FFMPEG = '/opt/bin/ffmpeg';
const JOBS_COLLECTION = 'aiInfluencerJobs';

// Initialize Firebase
const saBase64 = process.env.FIREBASE_SERVICE_ACCOUNT_KEY || process.env.FB_SERVICE_ACCOUNT_KEY;
if (!saBase64) {
    throw new Error('Missing Firebase Service Account Key (FIREBASE_SERVICE_ACCOUNT_KEY or FB_SERVICE_ACCOUNT_KEY)');
}
const serviceAccount = JSON.parse(Buffer.from(saBase64, 'base64').toString('utf-8'));
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        storageBucket: process.env.FIREBASE_STORAGE_BUCKET || 'text2video-16cbf.firebasestorage.app',
    });
}

// ────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────

async function updateJobDoc(jobId, userId, fields) {
    const firestore = admin.firestore();
    await firestore
        .collection('users')
        .doc(userId)
        .collection(JOBS_COLLECTION)
        .doc(jobId)
        .set({ ...fields, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
}

/**
 * Downloads a file from any HTTP/HTTPS URL, following redirects.
 */
function downloadFromUrl(url) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        const req = client.get(url, (res) => {
            if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
                return downloadFromUrl(res.headers.location).then(resolve).catch(reject);
            }
            if (res.statusCode !== 200) {
                return reject(new Error(`Download failed with status ${res.statusCode} for URL: ${url}`));
            }
            const chunks = [];
            res.on('data', (c) => chunks.push(c));
            res.on('end', () => resolve(Buffer.concat(chunks)));
        });
        req.on('error', reject);
    });
}

async function uploadToFirebase(buffer, storagePath, contentType) {
    const bucket = admin.storage().bucket();
    const file = bucket.file(storagePath);
    await file.save(buffer, { metadata: { contentType } });
    await file.makePublic();
    return `https://storage.googleapis.com/${bucket.name}/${storagePath}`;
}

/**
 * Runs an FFmpeg command and returns a Promise.
 */
function runFfmpeg(args) {
    return new Promise((resolve, reject) => {
        console.log('🎬 Running ffmpeg:', FFMPEG, args.slice(0, 10).join(' '), '...');
        const proc = spawn(FFMPEG, args, { cwd: '/tmp' });
        let stderr = '';
        proc.stderr.on('data', (d) => { stderr += d.toString(); });
        proc.on('close', (code) => {
            if (code === 0) resolve();
            else reject(new Error(`ffmpeg exited ${code}. Stderr (last 2000 chars): ${stderr.slice(-2000)}`));
        });
        proc.on('error', reject);
    });
}

// ────────────────────────────────────────────────────
// Core branding processor
// ────────────────────────────────────────────────────

/**
 * Builds and executes the FFmpeg command that overlays the logo and/or
 * scrolling marquee on the input video.
 *
 * @param {string}  inputPath       - Path to the source video on disk
 * @param {string}  outputPath      - Where to write the branded output
 * @param {object}  opts
 * @param {string}  [opts.logoPath]       - Local path to the logo image (PNG/JPG)
 * @param {string}  [opts.marqueeText]    - Scrolling text string
 * @param {string}  [opts.marqueePosition] - 'top' | 'bottom'  (default: 'bottom')
 * @param {string}  [opts.logoPosition]   - 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left'
 */
async function applyBranding(inputPath, outputPath, opts = {}) {
    const { logoPath, marqueeText, marqueePosition = 'bottom', logoPosition = 'top-right' } = opts;

    const hasLogo    = !!logoPath    && fs.existsSync(logoPath);
    const hasMarquee = !!marqueeText && marqueeText.trim().length > 0;

    if (!hasLogo && !hasMarquee) {
        throw new Error('At least one of logo or marqueeText must be provided.');
    }

    // ── Build FFmpeg argument list ──────────────────────────────────────────
    const args = ['-i', inputPath];

    // Logo is a second input when present
    if (hasLogo) {
        args.push('-i', logoPath);
    }

    // ── video_size probe: the renderer encodes 360×640, but we keep it dynamic ──
    // We rely on FFmpeg expressions (W, H, w, h) so we don't hard-code resolution.

    // ── filter_complex ──────────────────────────────────────────────────────
    let filterParts = [];

    // Step 1: Scale base video to ensure consistent pixel format
    filterParts.push('[0:v]format=yuva420p[base]');

    let currentLabel = 'base';

    // Step 2: Overlay logo (scaled to ~7% of video width with preserved aspect)
    if (hasLogo) {
        // Scale logo: width = 7% of main video width, height auto (preserve aspect)
        // iw/ih refer to the LOGO input dimensions; W/H refer to main video
        filterParts.push(`[1:v]scale=iw*min(W*0.07/iw\\,H*0.07/ih):ih*min(W*0.07/iw\\,H*0.07/ih),format=yuva420p[logo_scaled]`);

        // Determine overlay X,Y based on logoPosition
        let overlayX, overlayY;
        const pad = 8; // pixels from the edge
        if (logoPosition === 'top-right') {
            overlayX = `W-w-${pad}`;
            overlayY = pad;
        } else if (logoPosition === 'top-left') {
            overlayX = pad;
            overlayY = pad;
        } else if (logoPosition === 'bottom-right') {
            overlayX = `W-w-${pad}`;
            overlayY = `H-h-${pad}`;
        } else { // bottom-left
            overlayX = pad;
            overlayY = `H-h-${pad}`;
        }

        filterParts.push(`[${currentLabel}][logo_scaled]overlay=${overlayX}:${overlayY}[after_logo]`);
        currentLabel = 'after_logo';
    }

    // Step 3: Scrolling marquee using drawtext
    if (hasMarquee) {
        // Escape special characters for FFmpeg drawtext filter
        const escaped = marqueeText
            .replace(/\\/g, '\\\\')
            .replace(/:/g, '\\:')
            .replace(/'/g, "\\'")
            .replace(/\[/g, '\\[')
            .replace(/\]/g, '\\]');

        // Vertical position:
        //   top    → 10px from top edge
        //   bottom → H - fontsize - box_border - 10px from bottom
        const fontSize = 18;
        const boxBorder = 4;
        const textY = marqueePosition === 'top'
            ? `${10 + boxBorder}`
            : `H-${fontSize + boxBorder * 2 + 10}`;

        // Scrolling: x goes from W (off-screen right) to -(text_width) (off-screen left)
        // Speed: 80 pixels per second — comfortable reading speed
        const scrollX = `W-mod(t*80\\,W+tw)`;

        filterParts.push(
            `[${currentLabel}]drawtext=` +
            `text='${escaped}':` +
            `fontsize=${fontSize}:` +
            `fontcolor=white:` +
            `box=1:` +
            `boxcolor=black@0.55:` +
            `boxborderw=${boxBorder}:` +
            `x=${scrollX}:` +
            `y=${textY}` +
            `[branded]`
        );
        currentLabel = 'branded';
    }

    // If we have logo only (no marquee), alias the last label to 'branded'
    if (hasLogo && !hasMarquee) {
        // Replace last filter's output label to 'branded'
        filterParts[filterParts.length - 1] = filterParts[filterParts.length - 1].replace(
            `[${currentLabel}]`,
            '[branded]'
        );
        currentLabel = 'branded';
    }

    const filterComplex = filterParts.join(';');

    args.push(
        '-filter_complex', filterComplex,
        '-map', '[branded]',
        '-map', '0:a',
        '-c:v', 'libx264',
        '-preset', 'medium',
        '-crf', '18',
        '-pix_fmt', 'yuv420p',
        '-c:a', 'copy',         // audio is unchanged — fastest path
        '-movflags', '+faststart',
        '-y',
        outputPath,
    );

    await runFfmpeg(args);
}

// ────────────────────────────────────────────────────
// Lambda Handler
// ────────────────────────────────────────────────────

/**
 * Event shape (all strings):
 * {
 *   jobId, userId,
 *   finalVideoUrl,          // The original rendered video URL
 *   logoBase64?,            // base64-encoded logo image
 *   logoMimeType?,          // e.g. "image/png"
 *   logoPosition?,          // 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left'
 *   marqueeText?,           // scrolling disclaimer text
 *   marqueePosition?,       // 'top' | 'bottom'
 * }
 */
exports.handler = async (event) => {
    const {
        jobId,
        userId,
        finalVideoUrl,
        logoBase64,
        logoMimeType,
        logoPosition   = 'top-right',
        marqueeText,
        marqueePosition = 'bottom',
    } = event;

    console.log(`🎨 BRANDING: Starting for Job ${jobId}`);
    console.log(`   Logo: ${logoBase64 ? 'YES (' + logoPosition + ')' : 'NO'}`);
    console.log(`   Marquee: ${marqueeText ? 'YES (' + marqueePosition + ')' : 'NO'}`);

    if (!jobId || !userId || !finalVideoUrl) {
        throw new Error('Missing required fields: jobId, userId, finalVideoUrl');
    }
    if (!logoBase64 && !marqueeText) {
        throw new Error('At least one of logoBase64 or marqueeText must be provided.');
    }

    const inputPath  = `/tmp/${jobId}-source.mp4`;
    const outputPath = `/tmp/${jobId}-branded.mp4`;
    let   logoPath   = null;

    try {
        await updateJobDoc(jobId, userId, { brandingStatus: 'processing' });

        // 1. Download source video
        console.log(`📹 Downloading source video: ${finalVideoUrl}`);
        const videoBuf = await downloadFromUrl(finalVideoUrl);
        fs.writeFileSync(inputPath, videoBuf);
        console.log(`   ✅ Source video saved (${(videoBuf.length / 1024 / 1024).toFixed(1)} MB)`);

        // 2. Save logo to disk if provided
        if (logoBase64) {
            const ext = (logoMimeType || 'image/png').includes('jpeg') ? 'jpg' : 'png';
            logoPath = `/tmp/${jobId}-logo.${ext}`;
            fs.writeFileSync(logoPath, Buffer.from(logoBase64, 'base64'));
            console.log(`   ✅ Logo saved to ${logoPath}`);
        }

        // 3. Apply branding with FFmpeg
        await applyBranding(inputPath, outputPath, {
            logoPath,
            marqueeText,
            marqueePosition,
            logoPosition,
        });

        // 4. Upload branded video to Firebase Storage
        const brandedBuffer = fs.readFileSync(outputPath);
        const storagePath   = `AIInfluencer/${jobId}/final-branded.mp4`;
        const brandedVideoUrl = await uploadToFirebase(brandedBuffer, storagePath, 'video/mp4');
        console.log(`   ✅ Branded video uploaded: ${brandedVideoUrl}`);

        // 5. Update Firestore — only add brandedVideoUrl, do not touch any existing fields
        await updateJobDoc(jobId, userId, {
            brandedVideoUrl,
            brandingStatus: 'complete',
        });

        // 6. Cleanup temp files
        [inputPath, outputPath, logoPath].filter(Boolean).forEach((p) => {
            try { fs.unlinkSync(p); } catch (_) {}
        });

        console.log(`✅ Branding complete for Job ${jobId}`);
        return { success: true, brandedVideoUrl };

    } catch (error) {
        console.error(`❌ Branding Error for Job ${jobId}:`, error);
        await updateJobDoc(jobId, userId, { brandingStatus: 'failed', brandingError: error.message });
        // cleanup on error too
        [inputPath, outputPath, logoPath].filter(Boolean).forEach((p) => {
            try { fs.unlinkSync(p); } catch (_) {}
        });
        throw error;
    }
};
