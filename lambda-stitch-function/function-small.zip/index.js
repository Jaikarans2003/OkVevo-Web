const admin = require('firebase-admin');
const { spawn } = require('child_process');
const fs = require('fs');

/**
 * AWS Lambda Handler for Video Stitching
 * Supports both HTTP (Function URL) and SQS triggers
 */

let firebaseInitialized = false;

function initializeFirebase() {
    if (firebaseInitialized) return;

    try {
        const serviceAccountBase64 = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;

        if (!serviceAccountBase64) {
            throw new Error('FIREBASE_SERVICE_ACCOUNT_KEY environment variable not set');
        }

        const serviceAccount = JSON.parse(
            Buffer.from(serviceAccountBase64, 'base64').toString('utf-8')
        );

        const bucketName = process.env.FIREBASE_STORAGE_BUCKET || 'text2video-16cbf.firebasestorage.app';
        console.log(`Initializing Firebase with bucket: ${bucketName}`);
        console.log(`Service account project_id: ${serviceAccount.project_id}`);

        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            storageBucket: bucketName
        });

        firebaseInitialized = true;
        console.log('✅ Firebase Admin SDK initialized successfully');
        console.log(`✅ Using storage bucket: ${bucketName}`);
    } catch (error) {
        console.error('❌ Failed to initialize Firebase Admin SDK:', error);
        throw error;
    }
}

/**
 * Download a video from Firebase Storage using Admin SDK
 */
async function downloadVideoFromFirebase(videoUrl, filename) {
    try {
        console.log(`Processing URL: ${videoUrl}`);

        const url = new URL(videoUrl);
        const pathMatch = url.pathname.match(/^\/[^\/]+\/(.+)$/);

        if (!pathMatch) {
            throw new Error(`Invalid Firebase URL format: ${videoUrl}`);
        }

        let filePath = decodeURIComponent(pathMatch[1]);
        console.log(`Extracted file path: ${filePath}`);

        const bucket = admin.storage().bucket();
        let file = bucket.file(filePath);
        let exists = await file.exists();

        if (!exists[0]) {
            console.warn(`File not found at: ${filePath}`);
            if (!filePath.startsWith('videos/')) {
                const altPath = `videos/${filePath.split('/').pop()}`;
                file = bucket.file(altPath);
                exists = await file.exists();
                if (exists[0]) {
                    filePath = altPath;
                }
            }
        }

        if (!exists[0]) {
            const [files] = await bucket.getFiles({ maxResults: 10 });
            console.log('Available files:', files.map(f => f.name));
            throw new Error(`File not found in Firebase Storage: ${filePath}`);
        }

        const destPath = `/tmp/${filename}`;
        await file.download({ destination: destPath });
        console.log(`✅ Downloaded ${filename}`);
        return destPath;

    } catch (error) {
        console.error(`❌ Error downloading ${filename}:`, error);
        throw error;
    }
}

/**
 * Get video duration using ffmpeg (since ffprobe may not be available)
 */
function getVideoDuration(videoPath) {
    return new Promise((resolve, reject) => {
        // Use ffmpeg to get duration from stderr output
        const ffmpeg = spawn('/opt/bin/ffmpeg', [
            '-i', videoPath,
            '-f', 'null',
            '-'
        ]);

        let stderr = '';
        ffmpeg.stderr.on('data', (data) => {
            stderr += data.toString();
        });

        ffmpeg.on('close', (code) => {
            // ffmpeg returns non-zero when using -f null, so we parse stderr regardless
            // Look for "Duration: HH:MM:SS.mmm" in the output
            const durationMatch = stderr.match(/Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})/);

            if (durationMatch) {
                const hours = parseInt(durationMatch[1]);
                const minutes = parseInt(durationMatch[2]);
                const seconds = parseFloat(durationMatch[3]);
                const duration = hours * 3600 + minutes * 60 + seconds;

                console.log(`Video duration for ${videoPath}: ${duration}s`);
                resolve(duration);
            } else {
                reject(new Error(`Could not parse duration from ffmpeg output for ${videoPath}`));
            }
        });

        ffmpeg.on('error', (error) => reject(error));
    });
}

/**
 * Stitch videos using FFmpeg with smooth crossfade transitions
 * Enhanced with better interpolation and quality settings
 * Now supports dynamic video durations and audio overlay
 * 
 * @param {string[]} inputFiles - Array of video file paths
 * @param {string} outputFile - Output file path
 * @param {string|null} audioFile - Optional narration audio file path
 */
async function stitchVideos(inputFiles, outputFile, audioFile = null) {
    // Probe all video durations first
    const durations = [];
    for (const file of inputFiles) {
        const duration = await getVideoDuration(file);
        durations.push(duration);
    }

    console.log('Video durations:', durations);

    return new Promise((resolve, reject) => {
        // Enhanced crossfade with smoother transition using easing curves
        // Using 'smoothleft' and 'smoothright' for natural feeling transitions
        // Increased transition duration to 1.5s for more cinematic effect
        const transitionDuration = 1.5;

        // Calculate dynamic offsets based on actual video durations
        // First transition: starts when first video is about to end
        const firstOffset = durations[0] - transitionDuration;

        // Second transition: starts at the end of the merged first two videos
        // After first xfade: total_duration = duration[0] + duration[1] - transitionDuration
        const secondOffset = durations[0] + durations[1] - (transitionDuration * 2);

        console.log(`Transition timings:`);
        console.log(`  First xfade: offset=${firstOffset}s (starts at ${firstOffset}s, ends at ${durations[0]}s)`);
        console.log(`  Second xfade: offset=${secondOffset}s (starts at ${secondOffset}s)`);
        console.log(`  Expected total duration: ${durations[0] + durations[1] + durations[2] - (transitionDuration * 2)}s`);

        // Build filter based on whether we have narration audio
        let filter;

        if (audioFile) {
            // WITH NARRATION AUDIO: Replace video audio completely with narration
            // Video audio will be muted, only narration will be used
            console.log('🎙️ Building filter with TTS narration ONLY (video audio muted)...');
            filter =
                // Normalize all video inputs
                `[0:v]scale=360:640:force_original_aspect_ratio=decrease,pad=360:640:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p[v0];` +
                `[1:v]scale=360:640:force_original_aspect_ratio=decrease,pad=360:640:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p[v1];` +
                `[2:v]scale=360:640:force_original_aspect_ratio=decrease,pad=360:640:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p[v2];` +
                // Video crossfade transitions
                `[v0][v1]xfade=transition=smoothleft:duration=${transitionDuration}:offset=${firstOffset}[vt1];` +
                `[vt1][v2]xfade=transition=smoothright:duration=${transitionDuration}:offset=${secondOffset}[outv]`;
            // Note: No audio filter needed - narration (input 3:a) will be mapped directly
        } else {
            // WITHOUT NARRATION: Original audio crossfade logic
            console.log('🎵 Building filter with video audio only...');
            filter =
                // Normalize all inputs
                `[0:v]scale=360:640:force_original_aspect_ratio=decrease,pad=360:640:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p[v0];` +
                `[1:v]scale=360:640:force_original_aspect_ratio=decrease,pad=360:640:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p[v1];` +
                `[2:v]scale=360:640:force_original_aspect_ratio=decrease,pad=360:640:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p[v2];` +
                // Video crossfade
                `[v0][v1]xfade=transition=smoothleft:duration=${transitionDuration}:offset=${firstOffset}[vt1];` +
                `[vt1][v2]xfade=transition=smoothright:duration=${transitionDuration}:offset=${secondOffset}[outv];` +
                // Audio crossfade
                `[0:a]atrim=0:${durations[0]},asetpts=PTS-STARTPTS[a0];` +
                `[1:a]atrim=0:${durations[1]},asetpts=PTS-STARTPTS[a1];` +
                `[2:a]atrim=0:${durations[2]},asetpts=PTS-STARTPTS[a2];` +
                `[a0][a1]acrossfade=d=${transitionDuration}:c1=tri:c2=tri[a01];` +
                `[a01][a2]acrossfade=d=${transitionDuration}:c1=tri:c2=tri[outa]`;
        }


        // Build FFmpeg arguments
        const args = [
            '-i', inputFiles[0],
            '-i', inputFiles[1],
            '-i', inputFiles[2]
        ];

        // Add audio input if provided
        if (audioFile) {
            args.push('-i', audioFile);
        }

        // Add filter and mapping
        args.push(
            '-filter_complex', filter,
            '-map', '[outv]'  // Map video from filter
        );

        // Map audio: narration if provided, otherwise filtered video audio
        if (audioFile) {
            args.push('-map', '3:a');  // Map narration audio directly (4th input = mute videos)
        } else {
            args.push('-map', '[outa]');  // Map filtered video audio
        }

        // Encoding settings
        args.push(
            '-c:v', 'libx264',
            '-preset', 'slow',        // Better quality encoding for smoother transitions
            '-crf', '20',             // Higher quality (lower CRF = better quality)
            '-profile:v', 'high',     // Use high profile for better compression
            '-level', '4.1',          // Compatibility level
            '-pix_fmt', 'yuv420p',    // Ensure compatibility
            '-c:a', 'aac',
            '-b:a', '256k',           // Higher audio bitrate for better quality
            '-ar', '48000',           // Standard audio sample rate
            '-movflags', '+faststart', // Enable fast start for web playback
            '-y',                     // Overwrite output file
            outputFile
        );

        console.log('Starting FFmpeg...');
        const ffmpeg = spawn('/opt/bin/ffmpeg', args);

        let stderr = '';
        ffmpeg.stderr.on('data', (data) => {
            stderr += data.toString();
            console.log('FFmpeg:', data.toString());
        });

        ffmpeg.on('close', (code) => {
            if (code === 0) {
                console.log('✅ Stitching complete');
                resolve();
            } else {
                console.error(`❌ FFmpeg failed: ${code}`);
                reject(new Error(`FFmpeg exited with code ${code}`));
            }
        });

        ffmpeg.on('error', (error) => reject(error));
    });
}

/**
 * Download audio file from Firebase Storage
 */
async function downloadAudioFromFirebase(audioUrl, filename) {
    try {
        console.log(`Downloading audio: ${audioUrl}`);

        const url = new URL(audioUrl);
        const pathMatch = url.pathname.match(/^\/[^\/]+\/(.+)$/);

        if (!pathMatch) {
            throw new Error(`Invalid Firebase audio URL format: ${audioUrl}`);
        }

        let filePath = decodeURIComponent(pathMatch[1]);
        console.log(`Extracted audio file path: ${filePath}`);

        const bucket = admin.storage().bucket();
        const file = bucket.file(filePath);
        const exists = await file.exists();

        if (!exists[0]) {
            throw new Error(`Audio file not found in Firebase Storage: ${filePath}`);
        }

        const destPath = `/tmp/${filename}`;
        await file.download({ destination: destPath });
        console.log(`✅ Downloaded audio: ${filename}`);
        return destPath;

    } catch (error) {
        console.error(`❌ Error downloading audio ${filename}:`, error);
        throw error;
    }
}

/**
 * Core stitching logic (extracted for reuse)
 */
async function processStitchingJob(videoUrls, sessionId = 'default', audioUrl = null) {
    console.log(`Processing stitching job: ${sessionId}`);
    console.log(`Video URLs:`, videoUrls);
    console.log(`Audio URL:`, audioUrl);

    // Download videos
    const downloadedVideos = [];
    for (let i = 0; i < videoUrls.length; i++) {
        const path = await downloadVideoFromFirebase(videoUrls[i], `video${i + 1}.mp4`);
        downloadedVideos.push(path);
    }

    // Download audio if provided
    let audioPath = null;
    if (audioUrl) {
        audioPath = await downloadAudioFromFirebase(audioUrl, 'narration.mp3');
    }

    // Stitch videos with or without audio
    const stitchedPath = '/tmp/stitched-output.mp4';
    await stitchVideos(downloadedVideos, stitchedPath, audioPath);

    // Upload to Firebase
    const timestamp = Date.now();
    const destinationFilename = `stitched-${sessionId}-${timestamp}.mp4`;

    const bucket = admin.storage().bucket();
    await bucket.upload(stitchedPath, {
        destination: `videos/${destinationFilename}`,
        metadata: { contentType: 'video/mp4' }
    });

    // Generate signed URL
    const file = bucket.file(`videos/${destinationFilename}`);
    const [url] = await file.getSignedUrl({
        action: 'read',
        expires: Date.now() + 7 * 24 * 60 * 60 * 1000
    });

    // Cleanup
    [...downloadedVideos, stitchedPath].forEach(path => {
        try { fs.unlinkSync(path); } catch (err) { }
    });

    console.log('✅ Stitching complete:', url);
    return url;
}

/**
 * Main Lambda Handler - Supports both HTTP and SQS triggers
 */
exports.handler = async (event) => {
    console.log('Lambda invoked');
    console.log('Event type:', event.Records ? 'SQS' : 'HTTP');

    try {
        initializeFirebase();

        // Detect trigger type
        if (event.Records && event.Records.length > 0) {
            // ========== SQS TRIGGER ==========
            console.log('🔹 SQS Trigger detected');

            // Process each SQS message (batch size = 1 recommended)
            for (const record of event.Records) {
                const body = JSON.parse(record.body);
                const { jobId, videoUrls, audioUrl } = body;

                if (!videoUrls || videoUrls.length !== 3) {
                    throw new Error('SQS message must contain 3 video URLs');
                }

                console.log(`Processing SQS job: ${jobId}`);
                const videoUrl = await processStitchingJob(videoUrls, jobId, audioUrl);

                console.log(`✅ SQS job ${jobId} completed: ${videoUrl}`);
                // Note: For SQS, the final video URL is returned in logs
                // You could send this to Firestore/SNS for frontend polling
            }

            // SQS doesn't need HTTP response, just return success
            return { statusCode: 200, body: 'SQS processing complete' };

        } else {
            // ========== HTTP TRIGGER (Legacy/Fallback) ==========
            console.log('🔹 HTTP Trigger detected');

            const body = event.body ? JSON.parse(event.body) : event;
            const { videoUrls, sessionId = 'default', audioUrl } = body;

            if (!videoUrls || videoUrls.length !== 3) {
                return {
                    statusCode: 400,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        success: false,
                        error: 'Must provide 3 video URLs'
                    })
                };
            }

            const videoUrl = await processStitchingJob(videoUrls, sessionId, audioUrl);

            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: true,
                    videoUrl,
                    message: 'Video stitched successfully'
                })
            };
        }

    } catch (error) {
        console.error('❌ Lambda error:', error);

        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                error: error.message || 'Stitching failed'
            })
        };
    }
};
