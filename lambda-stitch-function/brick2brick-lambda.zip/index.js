const admin = require('firebase-admin');
const { spawn } = require('child_process');
const fs = require('fs');

/**
 * AWS Lambda Handler for Video Stitching with URL support
 */

let firebaseInitialized = false;

function initializeFirebase() {
    if (firebaseInitialized) return;

    try {
        const serviceAccountBase64 = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;

        if (!serviceAccountBase64) {
            throw new Error('FIREBASE_SERVICE_ACCOUNT_KEY environment variable not set');
        }

        const serviceAccount = JSON.parse(
            Buffer.from(serviceAccountBase64, 'base64').toString('utf-8')
        );

        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            storageBucket: process.env.FIREBASE_STORAGE_BUCKET || 'text2video-16cbf.appspot.com'
        });

        firebaseInitialized = true;
        console.log('Firebase Admin SDK initialized successfully');
    } catch (error) {
        console.error('Failed to initialize Firebase Admin SDK:', error);
        throw error;
    }
}

/**
 * Download a video from a URL to /tmp
 */
async function downloadVideoFromUrl(videoUrl, filename) {
    const https = require('https');
    const http = require('http');

    const protocol = videoUrl.startsWith('https') ? https : http;
    const destPath = `/tmp/${filename}`;
    const file = fs.createWriteStream(destPath);

    return new Promise((resolve, reject) => {
        protocol.get(videoUrl, (response) => {
            if (response.statusCode !== 200) {
                reject(new Error(`Failed to download: HTTP ${response.statusCode}`));
                return;
            }

            response.pipe(file);

            file.on('finish', () => {
                file.close();
                console.log(`Downloaded ${filename} from URL`);
                resolve(destPath);
            });
        }).on('error', (err) => {
            fs.unlink(destPath, () => { });
            reject(err);
        });

        file.on('error', (err) => {
            fs.unlink(destPath, () => { });
            reject(err);
        });
    });
}

/**
 * Stitch videos using FFmpeg with crossfade transitions
 */
function stitchVideos(inputFiles, outputFile) {
    return new Promise((resolve, reject) => {
        const filter =
            `[0:v][1:v]xfade=transition=fade:duration=1:offset=19[v01];` +
            `[v01][2:v]xfade=transition=fade:duration=1:offset=38,format=yuv420p[outv];` +
            `[0:a][1:a]acrossfade=d=1:c1=tri:c2=tri[a01];` +
            `[a01][2:a]acrossfade=d=1:c1=tri:c2=tri[outa]`;

        const args = [
            '-i', inputFiles[0],
            '-i', inputFiles[1],
            '-i', inputFiles[2],
            '-filter_complex', filter,
            '-map', '[outv]',
            '-map', '[outa]',
            '-c:v', 'libx264',
            '-preset', 'medium',
            '-crf', '23',
            '-c:a', 'aac',
            '-b:a', '192k',
            '-movflags', '+faststart',
            outputFile
        ];

        console.log('Starting FFmpeg with args:', args);

        const ffmpeg = spawn('/opt/bin/ffmpeg', args);

        let stderr = '';

        ffmpeg.stderr.on('data', (data) => {
            stderr += data.toString();
            console.log('FFmpeg:', data.toString());
        });

        ffmpeg.on('close', (code) => {
            if (code === 0) {
                console.log('FFmpeg stitching completed successfully');
                resolve();
            } else {
                console.error('FFmpeg failed with code:', code);
                console.error('FFmpeg stderr:', stderr);
                reject(new Error(`FFmpeg exited with code ${code}: ${stderr}`));
            }
        });

        ffmpeg.on('error', (error) => {
            console.error('FFmpeg spawn error:', error);
            reject(error);
        });
    });
}

/**
 * Main Lambda Handler
 */
exports.handler = async (event) => {
    console.log('Lambda invoked. Event:', JSON.stringify(event));

    try {
        // Initialize Firebase
        initializeFirebase();

        // Parse request body
        const body = event.body ? JSON.parse(event.body) : event;
        const { videoUrls, sessionId = 'default' } = body;

        if (!videoUrls || videoUrls.length !== 3) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    error: 'Request must include 3 video URLs'
                })
            };
        }

        console.log(`Processing video stitching for session: ${sessionId}`);
        console.log(`Video URLs:`, videoUrls);

        // Download videos from URLs
        console.log('Downloading videos from URLs...');
        const downloadedVideos = [];

        for (let i = 0; i < videoUrls.length; i++) {
            const destPath = await downloadVideoFromUrl(videoUrls[i], `video${i + 1}.mp4`);
            downloadedVideos.push(destPath);
        }

        // Stitch videos
        const stitchedPath = '/tmp/stitched-output.mp4';
        console.log('Stitching videos...');
        await stitchVideos(downloadedVideos, stitchedPath);

        // Upload to Firebase
        const timestamp = Date.now();
        const destinationFilename = `stitched-${sessionId}-${timestamp}.mp4`;
        console.log(`Uploading stitched video as ${destinationFilename}...`);

        const bucket = admin.storage().bucket();
        await bucket.upload(stitchedPath, {
            destination: `videos/${destinationFilename}`,
            metadata: {
                contentType: 'video/mp4'
            }
        });

        // Generate signed URL (valid for 7 days)
        const file = bucket.file(`videos/${destinationFilename}`);
        const [url] = await file.getSignedUrl({
            action: 'read',
            expires: Date.now() + 7 * 24 * 60 * 60 * 1000  // 7 days
        });

        console.log('Video stitching completed successfully');
        console.log('Signed URL:', url);

        // Clean up tmp files
        downloadedVideos.forEach(path => {
            try {
                fs.unlinkSync(path);
            } catch (err) {
                console.warn(`Failed to delete ${path}:`, err.message);
            }
        });

        try {
            fs.unlinkSync(stitchedPath);
        } catch (err) {
            console.warn('Failed to delete stitched file:', err.message);
        }

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            body: JSON.stringify({
                success: true,
                videoUrl: url,
                message: 'Video stitched successfully'
            })
        };

    } catch (error) {
        console.error('Lambda error:', error);

        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            body: JSON.stringify({
                success: false,
                error: error.message || 'Video stitching failed'
            })
        };
    }
};
